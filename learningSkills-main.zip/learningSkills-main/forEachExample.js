import { LightningElement } from 'lwc';

export default class ForEachExample extends LightningElement {
    contactList =["Michael","John","Vikky","Samuel","Kevin"];

}
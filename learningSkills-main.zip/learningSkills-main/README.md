# Getter methods examples in lwc
